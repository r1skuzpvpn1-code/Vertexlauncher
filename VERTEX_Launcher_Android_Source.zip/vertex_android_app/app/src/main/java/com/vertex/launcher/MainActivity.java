package com.vertex.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.DownloadManager;
import android.net.Uri;
import android.os.Environment;
import android.webkit.URLUtil;
import android.widget.Toast;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    WebView web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.setWebViewClient(new WebViewClient());
    web.setWebChromeClient(new WebChromeClient());
    web.setDownloadListener(new DownloadListener() {
      @Override public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
        try {
          DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
          request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
          request.setDescription("VERTEX Launcher download");
          request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
          request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));
          DownloadManager dm = (DownloadManager)getSystemService(DOWNLOAD_SERVICE);
          dm.enqueue(request);
          Toast.makeText(MainActivity.this, "Загрузка началась. Прогресс виден в уведомлениях.", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(MainActivity.this, "Не удалось начать загрузку", Toast.LENGTH_LONG).show(); }
      }
    });
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
}
