# VERTEX Launcher Mobile (prototype)

This is a native Android WebView wrapper around a mobile UI. It fetches Mojang's official version manifest, filters releases/snapshots/old beta/old alpha, fetches version JSON, and sends the client JAR download to Android Download Manager.

## Important limitations
- This is **not yet a full Minecraft Java launcher**: it does not install the full library/assets/native set, select/install Java, authenticate Microsoft, or launch Minecraft.
- Some historical versions may not have a client JAR URL in their metadata.
- This app does not bypass Minecraft account authentication or server licensing.

## Build APK in GitHub Actions
1. Create a GitHub repository and upload the contents of this folder.
2. Open **Actions** and run **Build VERTEX Android APK** (or push to `main`).
3. Open the completed workflow run and download the `VERTEX-Launcher-debug-apk` artifact.
4. Extract the artifact ZIP on Android; install `app-debug.apk`. Android may ask permission to install unknown apps.

Package ID: `com.vertex.launcher`. This debug APK is unsigned for Play Store release but is installable for testing.
